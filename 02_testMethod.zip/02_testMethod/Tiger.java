class Tiger{

	static String name;
	int age;

	void showInstance(int a,String n){
		System.out.println(name);
		System.out.println(age);
		showStatic();
	}

	static void showStatic(){
		
		Tiger t = new Tiger();
		t.age = 60;

		System.out.println(t.age);

		//showInstance();
		//System.out.println(age);
	}

	String getStringType(){
		String str ="Testing java";

		//return "Hello Java";
		return name;
	}




}