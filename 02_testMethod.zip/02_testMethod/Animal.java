class Animal{

	public static void main(String[] args) {

		Tiger t = new Tiger();
		String s = "hello";
		t.showInstance(23,s);
		t.showStatic();

		String str = t.getStringType();
		System.out.println(str);

		Tiger.showStatic();
		Tiger.name = "adsa";
		
	}
}