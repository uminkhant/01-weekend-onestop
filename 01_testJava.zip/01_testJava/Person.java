class Person{

	String name;
	static int age;
	int data = 222;

	void testLocal(){
		int count = 19;
		data = 23;

		System.out.println(count);

	}	

	void testLocalTwo(int data){
		System.out.println(data);
	}

}