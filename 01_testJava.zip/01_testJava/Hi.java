class Hi{


	public static void main(String[] args) {
		
		Person p = new Person();
		p.name = "Su Su";
		p.age = 23;

		System.out.println(p.name);
		System.out.println(p.age);

		p = new Person();
		System.out.println(p.name);
		System.out.println(p.age);

		System.out.println();
		System.out.println();

		p.testLocal();
		p.testLocalTwo(111);


		
	}
}
