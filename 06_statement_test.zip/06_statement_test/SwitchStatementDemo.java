
import java.util.Scanner;

class SwitchStatementDemo{

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		showGreeting("Welcome from Product");
		int res = askItem(sc);
		showOutput(res);
		showGreeting("Bye Bye");
		
	}

	//show greeting
	private static void showGreeting(String str){

		System.out.println();
		System.out.println("=================================");
		System.out.println();

		System.out.println(str);

		System.out.println();
		System.out.println("=================================");

	}

	//ask items
	
	private static int askItem(Scanner sc){

		System.out.println("""
			Please select One by number !
			1.Orange
			2.Apple
			3.Banana
			4.PileApple
			5.Watermelon

			""");

		int num = sc.nextInt();
		return num;

	}

	//check items
	//show output


	private static void showOutput(int i){

		String name = "";
		switch(i){
			case 1:
				name = "Orange";
				break;
			case 2:
				name = "Apple";
				break;
			case 3:
				name = "Banana";
				break;
			case 4:
				name = "PileApple";
				break;
			case 5:
				name = "Watermelon";
				break;
			default:
				name ="No Product";
				break;
		}

		System.out.println("Product name is :"+name);
	}








}