class LoopStatementDemo{
	private static int[] arr = {3,4,5,6,7,12,2,3};
	public static void main(String[] args) {
		enhanceForLoop();
	}

	static void enhanceForLoop(){
		for(int x:arr){
			System.out.println(x);
		}
	}
	

	static void testForLoop(){

		for(int i = arr.length-1;i>=0;){
			System.out.println(arr[i]);
			i--;
		}
	}

	static void testDoWhileLoop(){
		int size = 0;

		do{
			System.out.println(arr[size]);
			size++;
		}
		while(size < arr.length);
	}

	static void testWhileLoop(){
		int size = 0;

		while(size < arr.length){
			System.out.println(arr[size]);
			size++;
		}
	}



	
}