class BranchingStatementDemo{


	public static void main(String[] args) {
		testBranching();
	}

	private static void testBranching(){

			outer:	
			for (int x = 0 ;x < 5 ; x++) {
				for (int y = 0;y < 5 ;y++ ) {
					
					if(y == 3){
						break outer;
					}
					System.out.print("\tX :"+x+" Y :"+y);
				}
				System.out.println();
			}
	}
}