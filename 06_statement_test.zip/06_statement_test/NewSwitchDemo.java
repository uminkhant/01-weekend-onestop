
import java.util.Scanner;

class NewSwitchDemo{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//String s = sc.nextLine();
		//test(sc.nextLine());
		System.out.println("Please Type Day !");
		String res = testTwo(sc.nextLine());
		System.out.println(res);
	}

	static String testTwo(String name){
		return switch(name){

		case"Mon","Tue","Wed","Thur","Fri" ->{
			System.out.println("Hello ");
			yield "No need to go to JDC";
		} 
			
		case"Sat","Sun" ->  "Go to JDC";	
			
		default -> "Type Again";

		};

	}

	/*static void test(String name){
		switch(name){
		case"Mon","Tue","Wed","Thur","Fri":
			System.out.println("No need go to JDC");
			break;
		case"Sat","Sun":
			System.out.println("Go To Hell!");
			break;
		}

	}*/
}