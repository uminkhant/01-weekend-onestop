
import java.util.Scanner;

class IfElseStatementDemo{
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
	
		showGreeting("Welcome from Product");
		int res = askItem(sc);
		showOutput(res);
		showGreeting("Bye Bye");
		
	}

	//show greeting
	private static void showGreeting(String str){

		System.out.println();
		System.out.println("=================================");
		System.out.println();

		System.out.println(str);

		System.out.println();
		System.out.println("=================================");

	}

	//ask items
	//check items
	private static int askItem(Scanner sc){

		System.out.println("""
			Please select One by number !
				1.Orange
				2.Apple
				3.Banana
				4.PileApple
				5.Watermelon

			""");

		int num = sc.nextInt();
		return num;

	}

	//show output
	private static void showOutput(int i){

		String name = "";

		if(i <= 1 && i>0){
			name = "Orange";
		}else if(i == 2){
			name = "Apple";

		}else if( i == 3){
			name = "Banana";

		}else if( i == 4){
			name = "PileApple";

		}else if (i == 5){
			name = "Waterlemon";
		}else{
			name = "No product";
		}
		System.out.println("Product name is :"+name);
	}

}