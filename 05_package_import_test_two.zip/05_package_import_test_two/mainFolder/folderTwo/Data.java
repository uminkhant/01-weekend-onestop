package mainFolder.folderTwo;

public class Data{

	public void showData(int a){
		System.out.println("data :"+a);
	}
}