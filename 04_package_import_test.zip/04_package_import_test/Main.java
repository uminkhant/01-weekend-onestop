package package_import_test;

import package_import_test.folderOne.*;
import java.util.Scanner;

public class Main{
	public static void main(String[] args) {

		Person p = new Person();
		p.getStudent();

	}
}