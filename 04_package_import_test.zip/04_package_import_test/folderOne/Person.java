
package package_import_test.folderOne;

public class Person{

	public void getStudent(){

		Student st = new Student();
		st.defaultName = "default";
		st.privateName = "private";
		st.publicName = "public";
		st.protectedName = "protected";
	}
}