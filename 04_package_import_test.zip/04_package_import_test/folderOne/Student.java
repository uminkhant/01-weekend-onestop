package package_import_test.folderOne;

public class Student{

	String defaultName;
	private String privateName;
	protected String protectedName;
	public String publicName;

}