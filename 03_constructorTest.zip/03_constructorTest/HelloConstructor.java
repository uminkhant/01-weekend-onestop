public class HelloConstructor{

	public static void main(String[] args) {
		
		Student st = new Student("aaa");


	}
}

class Student{

	Student(String name){
		System.out.println("Hello Student "+name);
	}
}