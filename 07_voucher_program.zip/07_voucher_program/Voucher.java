class Voucher{

	private Item item;
	private int qty;
	private double total;

	Voucher(Item item,int qty){
		this.item = item;
		this.qty = qty;
	}

	public Item getItem(){
		return item;
	}

	public int getQty(){
		return qty;
	}

	public double getTotal(){
		return item.getPrice()*qty;
	}





}