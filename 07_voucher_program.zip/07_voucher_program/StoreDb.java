import java.util.Arrays;

class StoreDb{

	private Voucher[]vouchers;

	StoreDb(){
		vouchers = new Voucher[0];
	}

	public void saveToArray(Voucher vou){
		vouchers = Arrays.copyOf(vouchers,vouchers.length+1);
		vouchers[vouchers.length-1] = vou;
	}

	public Voucher[] getVouchers(){
		return vouchers;
	}


}