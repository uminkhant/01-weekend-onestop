import java.util.Scanner;
class Main{
	
	private static Scanner sc;
	private static StoreDb db;

	public static void main(String[] args) {
		
		sc = new Scanner(System.in);
		db = new StoreDb();

		greeting("Welcome to Our Product ");
		
		askSomeMoreOrNot();

		// if not ,show total
		showVoucher();

		//bye bye
		greeting("Bye Bye");
	}

	static void showVoucher(){
		System.out.println("Item Name\tPrice \t Qtys\tTotal");
		double totals = 0;
		for(Voucher v :db.getVouchers()){
			System.out.println(v.getItem().getName()+" \t \t"
				+ v.getItem().getPrice()+" \t "
				+ v.getQty()+" \t "
				+ v.getTotal());
			totals += v.getTotal();
		}

		System.out.println("-----------------------------");
		System.out.println();
		System.out.println("Total Prices :"+totals);
	}

	//greeting
	static void greeting(String str){
		System.out.println();
		System.out.println("======================================");
		System.out.println();

		System.out.println(str);
		System.out.println();
		System.out.println("======================================");
	}

	//show and select
	//select item
	//type qty
	static void showAndSelectItem(){
		System.out.println("Type Item Name !");
		String name = sc.next();
		System.out.println("Type item price !");
		int price = sc.nextInt();
		System.out.println("Type Qty for your selected item !");
		int qty = sc.nextInt();

		Item item = new Item (name,price);
		Voucher vou = new Voucher(item,qty);
		
		//save to array
		db.saveToArray(vou);
	}


//ask ? do u want some more ?
	static void askSomeMoreOrNot(){
		String res = "";
		do{
			showAndSelectItem();
			System.out.println("Do you want some more item /y");
			res = sc.next();

		}while(res.equals("y"));
	}








}